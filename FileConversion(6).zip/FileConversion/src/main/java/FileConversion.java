import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.util.List;
import java.util.Map;

public class FileConversion implements ItemListener, ActionListener {

    static Choice menu;
    static JTextField text;
    static JTextField fileLocationField;
    static JTextField fileDesLocationField;
    //String selectedChoice = "";

    public static void main(String[] args) {

        //Create a frame
        JFrame frame = new JFrame("Choice Menu");
        frame.setSize(800, 800);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // frame.setLayout(null);
        frame.getContentPane().setBackground(Color.white);
        //Create a choice menu
        menu = new Choice();
        menu.setBounds(100, 100, 120, 60);
        frame.add(menu);
        //Add items to the menu
        menu.add(".csv to .json");
        //menu.add(".json to .csv");

        //Create a text field for output
        text = new JTextField();
        text.setBounds(0, 400, 500, 100);
        frame.add(text);

        fileLocationField = new JTextField(16);

        // create a label to display text
        JLabel fileLocationLabel = new JLabel("Enter file location");

        fileDesLocationField = new JTextField(16);

        // create a label to display text
        JLabel fileDesLocationLabel = new JLabel("Enter destination location");
        fileDesLocationLabel.setBounds(0, 200, 120, 60);

        JButton convertBtn = new JButton("convert");

        JPanel p = new JPanel();

        // add buttons and textfield to panel
        p.add(fileLocationField);
        p.add(fileLocationLabel);
        p.add(fileDesLocationField);
        p.add(fileDesLocationLabel);
        p.add(convertBtn);
        frame.add(p);

        //Create an object
        FileConversion obj = new FileConversion();
        //Associate ItemListener with the choice menu
        menu.addItemListener(obj);
        convertBtn.addActionListener(obj);
        //Display the frame
        frame.setVisible(true);

    }

    @Override
    public void itemStateChanged(ItemEvent e) {
        String item = menu.getSelectedItem();
        text.setText("Selected : " + item);
        //selectedChoice = item;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //convert Button
        String s = e.getActionCommand();
        if (s.equals("convert")) {
            text.setText("converted successfully");

            File input = new File(fileLocationField.getText() + ".csv");
            File output = new File(fileDesLocationField.getText() + "convertedJson" + ".txt");

            csvToJson(input, output);

        }
    }


    public static void csvToJson(File input, File output) {
        // File input = new File("input.csv");
        try {
            CsvSchema csv = CsvSchema.emptySchema().withHeader();
            CsvMapper csvMapper = new CsvMapper();
            MappingIterator<Map<?, ?>> mappingIterator = csvMapper.reader().forType(Map.class).with(csv).readValues(input);
            List<Map<?, ?>> list = mappingIterator.readAll();
            System.out.println(list);

            ObjectMapper mapper = new ObjectMapper();

            mapper.enable(SerializationFeature.INDENT_OUTPUT);


            // File output = new File("E:\\7th sem" + "fileName" + ".txt");

            mapper.writerWithDefaultPrettyPrinter().writeValue(output, list);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
